#pragma once

#include "Program.h"





class test
{
public:
	bool test1();
	bool test2();
	bool test3();
	bool test4();
	bool test5(int num);
	void testWrapper();
private:
	Queue ex;
	Data sample;

};




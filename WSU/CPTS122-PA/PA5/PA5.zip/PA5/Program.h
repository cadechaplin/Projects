#pragma once
#include "queue.h"



void program(int num);// runs program with the number of minutes that is given to it 